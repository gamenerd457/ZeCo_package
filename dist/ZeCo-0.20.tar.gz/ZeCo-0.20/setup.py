from setuptools import setup

setup(
    name="ZeCo",version="0.20",description="this package is used to train an image classifier",packages=['ZeCo']
)